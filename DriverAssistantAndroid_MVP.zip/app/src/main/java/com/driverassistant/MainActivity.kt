package com.driverassistant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("driver_assistant", MODE_PRIVATE)
        setContent {
            MaterialTheme {
                DriverApp(
                    initialFuel = prefs.getString("fuel", "2.15") ?: "2.15",
                    initialConsumption = prefs.getString("consumption", "6.5") ?: "6.5",
                    onSave = { fuel, consumption ->
                        prefs.edit().putString("fuel", fuel).putString("consumption", consumption).apply()
                    },
                    onOverlay = { toggleOverlay() },
                    onOcr = { uri, done -> recognizeScreenshot(uri, done) }
                )
            }
        }
    }

    private fun toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            startService(Intent(this, OverlayService::class.java))
        }
    }

    private fun recognizeScreenshot(uri: Uri, done: (String) -> Unit) {
        try {
            val image = InputImage.fromFilePath(this, uri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { done(it.text) }
                .addOnFailureListener { done("OCR error: ${it.localizedMessage}") }
                .addOnCompleteListener { recognizer.close() }
        } catch (e: Exception) {
            done("Не удалось открыть изображение: ${e.localizedMessage}")
        }
    }
}

@Composable
private fun DriverApp(
    initialFuel: String,
    initialConsumption: String,
    onSave: (String, String) -> Unit,
    onOverlay: () -> Unit,
    onOcr: (Uri, (String) -> Unit) -> Unit
) {
    var platform by remember { mutableStateOf("Uber") }
    var pay by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var fuel by remember { mutableStateOf(initialFuel) }
    var consumption by remember { mutableStateOf(initialConsumption) }
    var threshold by remember { mutableStateOf("0.40") }
    var target by remember { mutableStateOf("0.50") }
    var extra by remember { mutableStateOf("0") }
    var ocrText by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onOcr(uri) { text ->
            ocrText = text
            // OCR suggestions are provisional; driver must verify before using them.
            val euro = Regex("""(?i)(\d+[.,]?\d*)\s*€""").find(text)?.groupValues?.get(1)
            val distance = Regex("""(?i)(\d+[.,]?\d*)\s*(km|kms)""").find(text)?.groupValues?.get(1)
            if (euro != null) pay = euro.replace(',', '.')
            if (distance != null) km = distance.replace(',', '.')
        }
    }

    val p = pay.toDoubleOrNull() ?: 0.0
    val d = km.toDoubleOrNull() ?: 0.0
    val f = fuel.toDoubleOrNull() ?: 0.0
    val c = consumption.toDoubleOrNull() ?: 0.0
    val x = extra.toDoubleOrNull() ?: 0.0
    val fuelCost = d * f * c / 100.0
    val net = p - fuelCost - x
    val rate = if (d > 0) p / d else 0.0
    val minRate = threshold.toDoubleOrNull() ?: 0.40
    val targetRate = target.toDoubleOrNull() ?: 0.50
    val verdict = when {
        d <= 0 -> "Введи общий пробег"
        rate >= targetRate -> "ВЫГОДНО · ПРИНЯТЬ"
        rate >= minRate -> "СРЕДНИЙ ЗАКАЗ · ПО ТВОЕМУ РЕШЕНИЮ"
        else -> "НЕВЫГОДНО · ОТКЛОНИТЬ"
    }

    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(p, d, fuelCost, net, rate, verdict, platform) {
        context.getSharedPreferences("driver_assistant", android.content.Context.MODE_PRIVATE)
            .edit()
            .putString("overlay_text", "$platform | ${"%.2f".format(p)}€ | ${"%.2f".format(d)} km\n${"%.2f".format(rate)} €/km · ${"%.2f".format(net)}€ net\n$verdict")
            .apply()
    }

    Scaffold { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("DRIVER ASSISTANT", style = MaterialTheme.typography.headlineSmall)
            Text("Uber + Glovo · Hybrid MVP")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = platform == "Uber", onClick = { platform = "Uber" }, label = { Text("Uber") })
                FilterChip(selected = platform == "Glovo", onClick = { platform = "Glovo" }, label = { Text("Glovo") })
            }
            OutlinedTextField(pay, { pay = it }, label = { Text("Оплата заказа (€)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(km, { km = it }, label = { Text("Общий пробег (км)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(extra, { extra = it }, label = { Text("Дополнительные расходы (€)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                Text("Распознать скриншот предложения (OCR)")
            }
            Text("Выбери скриншот из галереи. Проверь распознанные цену и километры перед расчётом.",
                style = MaterialTheme.typography.bodySmall)
            if (ocrText.isNotBlank()) {
                Text("Распознанный текст:", style = MaterialTheme.typography.titleSmall)
                Text(ocrText.take(1200), style = MaterialTheme.typography.bodySmall)
            }
            HorizontalDivider()
            Text("Автомобиль и критерии", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(fuel, { fuel = it; onSave(it, consumption) }, label = { Text("Бензин €/л") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(consumption, { consumption = it; onSave(fuel, it) }, label = { Text("Расход л/100 км") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(threshold, { threshold = it }, label = { Text("Минимальная ставка €/км") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(target, { target = it }, label = { Text("Целевая ставка €/км") }, modifier = Modifier.fillMaxWidth())
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(verdict, style = MaterialTheme.typography.titleMedium)
                    Text("Доход: ${"%.2f".format(p)} €")
                    Text("Топливо: ${"%.2f".format(fuelCost)} €")
                    Text("После топлива и доп. расходов: ${"%.2f".format(net)} €", style = MaterialTheme.typography.titleLarge)
                    Text("Ставка: ${"%.2f".format(rate)} €/км")
                }
            }
            Button(onClick = onOverlay, modifier = Modifier.fillMaxWidth()) { Text("Включить плавающее окно") }
            Text("Учитывай полный пробег: путь к точке, доставка и пустое возвращение. Налоги, обслуживание и амортизация пока не включены.",
                style = MaterialTheme.typography.bodySmall)
        }
    }
}
